// Duel Tools — shared settings-poll scheduler.
//
// WHY THIS EXISTS: a cluster of Appearance Customization scripts (Custom
// Colors ×5, Background Image, Card Language, DuelingBook Language, Custom
// Token Images, Custom Profile, Custom Emotes, Main Menu Image, Main Menu
// Sections) each used to run their OWN independent setInterval — nearly all
// on the same 1000-1500ms cadence, each doing its own chrome.storage.local
// read and DOM query/reapply pass — all ticking concurrently, forever, for
// the life of every duelingbook.com tab. That's over a dozen separate
// native timers all firing on overlapping schedules for what's
// fundamentally the same job repeated over and over: "did my setting or
// the DOM it touches change since last time — if so, reapply it."
//
// This file replaces all of those individual setIntervals with ONE real
// timer. Every script's own readAndApply()/applyAll() function is
// completely unchanged — same logic, same chrome.storage read, same DOM
// work, same idempotent re-apply — only WHO calls it on a schedule
// changes: instead of calling setInterval itself, a script now calls
// window.DTSharedPoll.register(fn, intervalMs) once, preserving its own
// original interval exactly (within this scheduler's TICK_MS resolution,
// which is fine enough that no cosmetic feature's timing is noticeably
// different).
//
// Injected FIRST in its group (background.js), same ordering requirement
// already documented there for dt-goat-errata-data.js in
// DECK_BUILDING_FILES: a `files` array passed to chrome.scripting.
// executeScript runs every listed file, in order, in ONE shared
// isolated-world scope — so an earlier file's top-level `window.X =`
// assignment is visible to every later file, in that same phase AND in
// every later phase for the same tab/page load (confirmed by this
// codebase's own window.__dtShimInstalled check in background.js, which
// relies on exactly this persistence across separate injectPhase calls).
(function () {
  'use strict';
  if (window.DTSharedPoll) return; // already installed earlier this page load — never double-start the tick

  const registrations = []; // { fn, intervalMs, lastRun }
  const TICK_MS = 250; // fine enough that every original 1000-2000ms cadence still lands within a quarter-second of its real schedule

  function tick() {
    const now = Date.now();
    for (let i = 0; i < registrations.length; i++) {
      const reg = registrations[i];
      if (now - reg.lastRun >= reg.intervalMs) {
        reg.lastRun = now;
        try { reg.fn(); } catch (e) { console.warn('[Duel Tools] DTSharedPoll registered callback threw:', e); }
      }
    }
  }

  window.DTSharedPoll = {
    // Registers fn to be called roughly every intervalMs, forever, via the
    // one shared timer instead of a fresh setInterval per caller. Running
    // fn once immediately on load is still each caller's own job (same as
    // before) — this only replaces the recurring setInterval(fn, ms) call.
    register: function (fn, intervalMs) {
      if (typeof fn !== 'function' || !intervalMs) return;
      // lastRun:0 so a newly-registered callback is eligible to fire on
      // the very next tick (within TICK_MS), matching how a fresh
      // setInterval(fn, ms) also doesn't wait a full `ms` before its very
      // first natural firing relative to when it was created.
      registrations.push({ fn: fn, intervalMs: intervalMs, lastRun: 0 });
    }
  };

  setInterval(tick, TICK_MS);

  console.log('[Duel Tools] shared poll scheduler ready');
})();
