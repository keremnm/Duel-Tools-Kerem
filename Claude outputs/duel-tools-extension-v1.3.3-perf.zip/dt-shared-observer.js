// Duel Tools — shared whole-document MutationObserver dispatcher.
//
// WHY THIS EXISTS: a handful of scripts need to react to ANY DOM change
// anywhere on the page (new menus appearing, card tiles re-rendering,
// chat/modals opening) and so watch document.body with
// {childList:true, subtree:true} — the broadest, most expensive scope a
// MutationObserver can have. Most of this extension's features that touch
// the DOM are already scoped to a much narrower container (a specific
// lobby/frames/duel element) — confirmed by reading every MutationObserver
// in this codebase — but a couple of genuinely page-wide features
// (DuelingBook Language, translating whatever text shows up anywhere;
// Historical Card Text, re-applying to whichever card tile just rendered)
// really do need to see the whole document, for the ENTIRE life of the
// tab, and each used to run its own independent document.body observer to
// do it. Two separate observers both watching the same document.body
// subtree means the browser computes and dispatches the same mutation
// record stream twice, once per observer, on every single DOM change
// DuelingBook's own JS makes — constantly, during an active duel.
//
// This file replaces those with ONE real document.body observer. Each
// script's own reaction logic (its onMutation/scheduleScan-style debounced
// re-check) is completely unchanged — only WHO owns the underlying
// MutationObserver changes: instead of creating its own, a script now
// calls window.DTSharedObserver.register(fn) once, and fn gets called
// with the same MutationRecord[] array a direct observer callback would
// have received.
//
// Injected FIRST in TRACKER_FILES (background.js) — the earliest
// unconditional phase — specifically so it's already installed before ANY
// later phase's scripts (deck-building, appearance-files, playing-files,
// lobby-files, main-menu-files) might want to register with it, following
// the same cross-phase, same-isolated-world persistence this codebase
// already relies on for window.__dtShimInstalled (see background.js).
(function () {
  'use strict';
  if (window.DTSharedObserver) return; // already installed earlier this page load

  const callbacks = [];
  let started = false;

  function dispatch(mutations) {
    for (let i = 0; i < callbacks.length; i++) {
      try { callbacks[i](mutations); } catch (e) { console.warn('[Duel Tools] DTSharedObserver registered callback threw:', e); }
    }
  }

  const observer = new MutationObserver(dispatch);

  window.DTSharedObserver = {
    // Registers fn to be called (with the raw MutationRecord[] array, same
    // shape a direct MutationObserver callback gets) whenever ANY mutation
    // fires anywhere under document.body, via the ONE shared observer
    // instead of a fresh page-wide MutationObserver per caller. Most
    // existing callers just ignore the argument and re-run their own
    // already-debounced scheduleScan()-style check from scratch, same as
    // before this change — this only changes who owns the underlying
    // observe() call.
    register: function (fn) {
      if (typeof fn !== 'function') return;
      callbacks.push(fn);
      if (!started) {
        started = true;
        observer.observe(document.body, { childList: true, subtree: true, characterData: true });
      }
    }
  };

  console.log('[Duel Tools] shared MutationObserver dispatcher ready');
})();
