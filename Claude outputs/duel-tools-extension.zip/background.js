// Duel Tools extension — background service worker.
//
// Two responsibilities:
//
//  1) Two-phase content script injection into DuelingBook tabs. The shim
//     (installShim, below — chrome.storage/chrome.runtime-backed
//     GM_getValue/GM_setValue/GM_xmlhttpRequest, plus an unsafeWindow
//     stand-in fed by page-bridge.js) must finish its async storage
//     preload BEFORE the actual tracker scripts run, since those files are
//     the EXACT, unmodified userscripts — the same files Tampermonkey used
//     to run — and they call GM_getValue synchronously the moment they
//     start. A static content_scripts array in manifest.json can't
//     guarantee that ordering: Chrome injects each listed file in order,
//     but doesn't wait for one file's async work to finish before starting
//     the next. chrome.scripting.executeScript calls, awaited in sequence
//     here instead, do guarantee it — an async `func` isn't considered
//     finished until its returned promise resolves.
//
//  2) Relaying GM_xmlhttpRequest calls (which the shim turns into
//     chrome.runtime messages) as real cross-origin fetches. That's done
//     here, not in the content script, because a service worker isn't
//     bound by a page's own CSP/CORS the way an isolated-world content
//     script's own fetch still can be — this mirrors what
//     GM_xmlhttpRequest's cross-origin bypass gave the original userscript
//     for free under Tampermonkey.

const TRACKER_FILES = ['dt-live-tracker.user.js', 'dt-save-prompt.user.js', 'dt-unlock.user.js'];
const RELAY_FILE = 'relay.user.js';
// Replay-only, like RELAY_FILE — adds Game 1/2/3 jump + Rewind Play buttons
// to DuelingBook's own replay viewer. Kept as its own file/phase (not added
// to TRACKER_FILES) since it only ever makes sense on a /replay* page.
const REPLAY_CONTROLS_FILE = 'dt-replay-controls.user.js';

// ── Phase 1: the shim — injected via `func`, not `files`, specifically so
// its returned promise is actually awaited before phase 2 starts. Must be
// fully self-contained: Chrome serializes this function to inject it, so
// it cannot close over anything from this file's outer scope.
async function installShim() {
  if (window.__dtShimInstalled) return;
  window.__dtShimInstalled = true;

  const cache = await chrome.storage.local.get(null);

  window.GM_getValue = function (key, def) {
    return Object.prototype.hasOwnProperty.call(cache, key) ? cache[key] : def;
  };
  window.GM_setValue = function (key, val) {
    cache[key] = val;
    chrome.storage.local.set({ [key]: val });
  };
  // dt-unlock.user.js declares this grant, but its module bodies are stubs
  // that don't actually call it yet — a safe no-op keeps it from throwing
  // once they do, without needing a real chrome.contextMenus wiring yet.
  window.GM_registerMenuCommand = function () {};

  window.GM_xmlhttpRequest = function (opts) {
    chrome.runtime.sendMessage(
      { source: 'dt-shim', type: 'DT_XHR', method: opts.method || 'GET', url: opts.url, headers: opts.headers, data: opts.data },
      function (resp) {
        if (chrome.runtime.lastError || !resp) {
          if (opts.onerror) opts.onerror(chrome.runtime.lastError || { error: 'no response' });
          return;
        }
        if (resp.error) { if (opts.onerror) opts.onerror(resp); return; }
        if (opts.onload) opts.onload({ status: resp.status, responseText: resp.responseText });
      }
    );
  };

  // ── unsafeWindow stand-in ────────────────────────────────────────────
  // A content script's own `window` is the ISOLATED world's window, not
  // the real page's — DuelingBook's own globals (currentLabel,
  // deck_filled_arr, side_filled_arr, initializeDeckCards) live only in
  // the MAIN world and are invisible here. page-bridge.js (injected
  // separately, with world:"MAIN") is the only thing that can actually see
  // them; it relays plain, serializable snapshots via postMessage, which
  // this listener turns back into the exact shape the unmodified tracker
  // code already expects — a `.data(key)` accessor per card, matching
  // DuelingBook's own jQuery-backed CardFront elements.
  const uw = { currentLabel: undefined, deck_filled_arr: [], side_filled_arr: [], initializeDeckCards: function () {} };
  window.unsafeWindow = uw;

  function toFakeCard(meta) {
    return { data: function (key) { return meta[key]; } };
  }
  function applySnapshot(msg) {
    if ('currentLabel' in msg) uw.currentLabel = msg.currentLabel;
    if (Array.isArray(msg.deckArr)) uw.deck_filled_arr = msg.deckArr.map(toFakeCard);
    if (Array.isArray(msg.sideArr)) uw.side_filled_arr = msg.sideArr.map(toFakeCard);
  }
  window.addEventListener('message', function (ev) {
    if (!ev.data || ev.data.source !== 'dt-page-bridge') return;
    if (ev.data.type === 'DT_BRIDGE_SNAPSHOT') {
      applySnapshot(ev.data);
    } else if (ev.data.type === 'DT_BRIDGE_SIDING_CHANGED') {
      applySnapshot(ev.data);
      try { uw.initializeDeckCards(); } catch (e) { console.log('[Duel Tools Shim] siding hook relay error:', e); }
    }
  });
  // Covers reads that need to happen independent of a real
  // initializeDeckCards call — e.g. noticing the siding screen re-opened
  // for a new game, before any swap has happened yet.
  setInterval(function () {
    window.postMessage({ source: 'dt-content-shim', type: 'DT_BRIDGE_REQUEST' }, window.location.origin);
  }, 200);

  console.log('[Duel Tools Shim] ready');
}

async function injectAll(tabId, url) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', files: ['page-bridge.js'] });
    await chrome.scripting.executeScript({ target: { tabId }, func: installShim });
    await chrome.scripting.executeScript({ target: { tabId }, files: TRACKER_FILES });
    if (/\/replay/.test(url)) {
      // RELAY_FILE (relay.user.js) is deliberately NOT injected right now —
      // it POSTs to /api/relay/replay, which doesn't exist anywhere on the
      // server (confirmed by grep), so every run of it was silently
      // failing. Parked here, hidden, until it's rebuilt with a real
      // destination or retired for good — the file itself is untouched so
      // picking it back up later is just adding it back to this list.
      await chrome.scripting.executeScript({ target: { tabId }, files: [REPLAY_CONTROLS_FILE] });
    }
  } catch (e) {
    console.log('[Duel Tools] injection failed:', e);
  }
}

chrome.webNavigation.onCommitted.addListener(function (details) {
  if (details.frameId !== 0) return; // top frame only
  let host;
  try { host = new URL(details.url).hostname; } catch (e) { return; }
  if (host !== 'www.duelingbook.com' && host !== 'duelingbook.com') return;
  injectAll(details.tabId, details.url);
});

// ── XHR relay — the actual cross-origin fetch, run from the service worker
// so it's never subject to duelingbook.com's own CSP/CORS the way an
// isolated-world content script's fetch still can be.
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.source !== 'dt-shim' || msg.type !== 'DT_XHR') return false;
  (async () => {
    try {
      const res = await fetch(msg.url, {
        method: msg.method || 'GET',
        headers: msg.headers || undefined,
        body: msg.data || undefined
      });
      const responseText = await res.text();
      sendResponse({ status: res.status, responseText: responseText });
    } catch (e) {
      sendResponse({ error: true, message: String(e) });
    }
  })();
  return true; // keep the message channel open for the async sendResponse above
});
