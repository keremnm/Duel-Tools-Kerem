// ==UserScript==
// @name         Duel Tools — Replay Controls
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  Adds Game 1/2/3/Next Game jump buttons and a Rewind Play button next to DuelingBook's own replay viewer controls.
// @match        https://www.duelingbook.com/replay*
// @grant        none
// @run-at       document-idle
// ==/UserScript==
(function () {
  'use strict';

  // ── v2: rebuilt against a REAL DuelingBook replay (confirmed live, not
  // guessed) ───────────────────────────────────────────────────────────────
  // v1 of this script guessed at the mechanism from screenshots alone. This
  // version was built by actually driving a real replay
  // (duelingbook.com/replay?id=793224-85215072) and recording what's
  // genuinely there:
  //
  //  - The Duel Log prints an exact, unambiguous section header the moment
  //    game 2+ begins: "---------(Game 2 - Turn 1)---------",
  //    "---------(Game 3 - Turn 1)---------", etc. Game 1 has no such
  //    marker (its turn headers are plain "----(Turn 1)----"). So "what
  //    game are we on right now" is just: the highest N in any
  //    "(Game N - Turn ...)" marker seen so far in the log, or 1 if none.
  //    This is exact and needs no guessing at log-line verbs.
  //  - A replay auto-plays continuously on its own (like watching the
  //    match happen live, at its original pace) — it is NOT a static,
  //    paused-by-default viewer. "Play"/"Pause" are two separate always-
  //    present buttons (not one toggling label); whichever one is
  //    currently inactive carries a "disabled" class, which is how this
  //    script tells which state it's in. "Fast Forward" speeds up that
  //    same auto-play rather than being a one-shot skip. "Next Play" steps
  //    exactly one logged action, same whether paused or playing.
  //  - DuelingBook's own "Next Game" button (the one that appears under
  //    the bottom player's banner) turned out to be a no-op in every real
  //    test during replay viewing — clicking it produced zero change to
  //    the Duel Log, both mid-game and right at a game boundary. It may be
  //    a live-match-only control (confirming both players are ready to
  //    continue). So this script does NOT depend on it: the "Next Game"
  //    button this script adds is built the same way the G1/G2/G3 buttons
  //    are (jump to game = current + 1), which is confirmed to work.
  //  - There is still no native "step backward" of any kind. "Rewind
  //    Play" is still built by reloading the replay and auto-replaying
  //    forward to one play short of where you were — now done properly:
  //    "Fast Forward" to get close, then exact single "Next Play" steps
  //    for the last few plays, instead of single-stepping the entire way
  //    (which was correct but needlessly slow).
  //
  // A jump is never instant — DuelingBook's replay has no seek/scrub
  // primitive at all, native "Next Game" included (as far as this could
  // find); every control here works by actually playing the replay
  // forward, just as fast as "Fast Forward" itself goes. A jump to a late
  // game, or a Rewind deep into a long game, can take real seconds to
  // tens of seconds — the console logs progress throughout so it's clear
  // it's working, not stuck.

  const idMatch = /([0-9]{4,9}-[0-9]{5,10})/.exec(window.location.search + window.location.pathname);
  const REPLAY_ID = idMatch ? idMatch[1] : 'unknown';
  const TARGET_KEY = 'dt_replay_' + REPLAY_ID + '_target';

  function log(msg) { console.log('[Duel Tools Replay]', msg); }
  function warn(msg) { console.warn('[Duel Tools Replay]', msg); }

  function loadTarget() {
    try {
      const raw = sessionStorage.getItem(TARGET_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }
  function saveTarget(t) {
    try {
      if (t) sessionStorage.setItem(TARGET_KEY, JSON.stringify(t));
      else sessionStorage.removeItem(TARGET_KEY);
    } catch (e) {}
  }

  // ── Reading DuelingBook's own state, read-only ──────────────────────────
  function findByExactText(text) {
    const all = document.querySelectorAll('body *');
    for (const el of all) {
      const t = (el.textContent || '').trim();
      if (t !== text) continue;
      let isLeaf = true;
      for (const c of el.children) {
        if ((c.textContent || '').trim() === text) { isLeaf = false; break; }
      }
      if (isLeaf && el.offsetParent !== null) return el;
    }
    return null;
  }
  function logText() {
    const el = document.querySelector('#duel_log');
    return el ? el.textContent : '';
  }
  // The exact marker confirmed live: "---------(Game 2 - Turn 1)---------".
  // Takes the highest game number seen so far; 1 if none yet (game 1 has
  // no marker of its own).
  function currentGameNumber() {
    const matches = [...logText().matchAll(/\(Game (\d+) - Turn \d+\)/g)];
    if (!matches.length) return 1;
    return Math.max.apply(null, matches.map((m) => parseInt(m[1], 10)));
  }
  // Every individual logged action, one per line, same shape dt-live-
  // tracker.user.js already relies on elsewhere in this project.
  function playCount() {
    const el = document.querySelector('#duel_log');
    if (!el) return 0;
    return Array.from(el.querySelectorAll('*')).filter((n) => {
      const t = (n.textContent || '').trim();
      return /^\[\d+:\d+\]/.test(t) && n.children.length === 0;
    }).length;
  }
  function isDisabled(el) { return !el || el.className.indexOf('disabled') !== -1; }

  function clickFastForward() {
    const btn = findByExactText('Fast Forward');
    if (btn) btn.click();
    return !!btn;
  }
  function clickPause() {
    const btn = findByExactText('Pause');
    if (btn && !isDisabled(btn)) btn.click();
  }
  function clickNextPlayOnce() {
    const btn = findByExactText('Next Play');
    if (!btn) return false;
    btn.click();
    return true;
  }
  function sleep(ms) { return new Promise((r) => setTimeout(r, ms)); }

  // ── Core seek primitives ────────────────────────────────────────────────
  // Poll `isDone` every `intervalMs`, giving up after `maxMs`. Returns true
  // if `isDone` was reached, false on timeout.
  async function pollUntil(isDone, intervalMs, maxMs) {
    const deadline = Date.now() + maxMs;
    while (!isDone()) {
      if (Date.now() > deadline) return false;
      await sleep(intervalMs);
    }
    return true;
  }

  // Jump FORWARD to the start of game `n` (n must be >= currentGameNumber()).
  async function fastForwardToGame(n) {
    log('fast-forwarding to Game ' + n + ' (currently Game ' + currentGameNumber() + ')...');
    if (!clickFastForward()) { warn('could not find "Fast Forward" — giving up.'); return; }
    const ok = await pollUntil(() => currentGameNumber() >= n, 400, 180000); // up to 3 real minutes — a long match can genuinely take this long to play through
    clickPause();
    if (ok) log('arrived at Game ' + n + '.');
    else warn('gave up waiting to reach Game ' + n + ' after 3 minutes — the match may not have that many games, or something unexpected happened. Check the Duel Log.');
  }

  // Step forward to an EXACT play count: fast-forward to get close, then
  // single-step the last few plays for an exact landing (Fast Forward can
  // advance several plays between polls, so it alone can't guarantee
  // landing on one exact play — single-stepping the final stretch can).
  async function advanceToExactPlayCount(target) {
    const MARGIN = 5;
    if (playCount() < target - MARGIN) {
      log('fast-forwarding toward play ' + target + '...');
      clickFastForward();
      await pollUntil(() => playCount() >= target - MARGIN, 400, 180000);
      clickPause();
    }
    log('single-stepping the last few plays to land exactly on play ' + target + '...');
    while (playCount() < target) {
      if (!clickNextPlayOnce()) { warn('"Next Play" disappeared before reaching the target — giving up.'); return; }
      await sleep(300);
    }
    clickPause();
    log('landed on play ' + target + '.');
  }

  let busy = false;
  async function seekToGame(n) {
    if (busy) { warn('already seeking — ignoring overlapping request.'); return; }
    busy = true;
    try {
      const cur = currentGameNumber();
      if (n === cur) { log('already on Game ' + n + '.'); clickPause(); return; }
      if (n < cur) {
        log('Game ' + n + ' is behind the current position (Game ' + cur + ') — reloading the replay from the start...');
        saveTarget({ type: 'game', value: n });
        location.reload();
        return; // page is reloading; resumePendingTarget() picks this up after
      }
      await fastForwardToGame(n);
    } finally {
      busy = false;
    }
  }

  async function rewindOnePlay() {
    if (busy) { warn('already busy — ignoring overlapping request.'); return; }
    const cur = playCount();
    if (cur <= 0) { log('already at the very first play.'); return; }
    const target = cur - 1;
    busy = true;
    try {
      log('rewinding one play (' + cur + ' → ' + target + ') — reloading the replay from the start...');
      saveTarget({ type: 'playCount', value: target });
      location.reload();
    } finally {
      busy = false; // page is reloading regardless; this mostly matters if reload is somehow blocked
    }
  }

  // ── Resume a pending jump/rewind after a reload ─────────────────────────
  (function resumePendingTarget() {
    const t = loadTarget();
    if (!t) return;
    saveTarget(null);
    setTimeout(async function () {
      busy = true;
      try {
        if (t.type === 'playCount') {
          log('resuming after reload — advancing to play ' + t.value + '...');
          await advanceToExactPlayCount(t.value);
        } else if (t.type === 'game') {
          if (t.value <= 1) { log('resumed at Game 1 (reload alone was enough).'); return; }
          log('resuming after reload — fast-forwarding to Game ' + t.value + '...');
          await fastForwardToGame(t.value);
        }
      } finally {
        busy = false;
      }
    }, 1500); // let DuelingBook finish its own post-reload setup first
  })();

  // ── UI: a small panel positioned relative to the native control stack
  // (measured live, so it lands in the right spot regardless of window
  // size — DuelingBook's board is a responsively-scaled canvas, so a fixed
  // pixel offset copied from one window size would land wrong in another).
  function btnStyle() {
    return 'background:#222;color:#9ac;border:1px solid #333;border-radius:5px;padding:5px 4px;' +
      'cursor:pointer;font-family:monospace;font-size:11px;flex:1';
  }
  function buildControls() {
    if (document.getElementById('dt-replay-controls')) return;
    const fastForwardBtn = findByExactText('Fast Forward');
    if (!fastForwardBtn) { setTimeout(buildControls, 500); return; } // retry until DuelingBook's own controls exist

    const panel = document.createElement('div');
    panel.id = 'dt-replay-controls';
    panel.style.cssText = [
      'position:fixed', 'z-index:2147483000',
      'background:#111', 'color:#eee', 'border:1px solid #333', 'border-radius:8px',
      'font-family:monospace', 'font-size:11px', 'padding:8px', 'width:140px',
      'box-shadow:0 6px 24px rgba(0,0,0,.5)'
    ].join(';');
    panel.innerHTML =
      '<div style="color:#666;margin-bottom:6px">Duel Tools</div>' +
      '<div style="display:flex;gap:4px;margin-bottom:4px">' +
        '<button data-dt-game="1" style="' + btnStyle() + '" title="Jump to Game 1">G1</button>' +
        '<button data-dt-game="2" style="' + btnStyle() + '" title="Jump to Game 2">G2</button>' +
        '<button data-dt-game="3" style="' + btnStyle() + '" title="Jump to Game 3">G3</button>' +
      '</div>' +
      '<button id="dt-next-game" style="' + btnStyle() + ';width:100%;margin-bottom:4px" title="Jump to the next game (covers Game 4+, rare)">Next Game ▶</button>' +
      '<button id="dt-rewind-play" style="' + btnStyle() + ';width:100%" title="Step back one play (opposite of Next Play)">⏪ Rewind</button>';
    document.body.appendChild(panel);

    // Prefers sitting just below the native control stack (where the user
    // pointed to), but DuelingBook's board is responsively scaled and can
    // fill the ENTIRE window height with zero margin below the controls
    // (confirmed live: on one real window size the control stack's own
    // bottom edge was already flush with the window's bottom edge) — so
    // this clamps to stay fully on-screen instead of running off the
    // bottom, falling back to beside the controls when there's truly no
    // vertical room at all.
    function reposition() {
      const r = fastForwardBtn.getBoundingClientRect();
      const panelH = panel.offsetHeight || 100;
      const panelW = panel.offsetWidth || 140;
      let left = r.left;
      let top = r.bottom + 10;
      if (top + panelH > window.innerHeight) {
        // No room below — place beside the controls instead, same top as
        // the control stack itself, still fully on-screen either way.
        top = Math.max(4, Math.min(r.top, window.innerHeight - panelH - 4));
        left = r.right + 10;
        if (left + panelW > window.innerWidth) left = Math.max(4, r.left - panelW - 10);
      }
      panel.style.left = left + 'px';
      panel.style.top = top + 'px';
    }
    reposition();
    window.addEventListener('resize', reposition);

    panel.querySelectorAll('button[data-dt-game]').forEach(function (btn) {
      btn.addEventListener('click', function () { seekToGame(parseInt(btn.dataset.dtGame, 10)); });
    });
    panel.querySelector('#dt-next-game').addEventListener('click', function () { seekToGame(currentGameNumber() + 1); });
    panel.querySelector('#dt-rewind-play').addEventListener('click', rewindOnePlay);

    log('controls added below Fast Forward (Game ' + currentGameNumber() + ' right now).');
  }
  buildControls();
})();
